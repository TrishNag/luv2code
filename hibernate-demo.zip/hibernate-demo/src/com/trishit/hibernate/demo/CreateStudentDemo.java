package com.trishit.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.trishit.hibernate.entity.Student;

public class CreateStudentDemo {

	public static void main(String[] args) {

	
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class)
				.buildSessionFactory();

		Session session = sessionFactory.getCurrentSession();

		try {
			System.out.println("Creating Student Database Object");
			Student tempStudent = new Student("Trishit", "Nag", "trishitnag@gmail.com");
			session.beginTransaction();
			System.out.println("Saving Student Database Object");
			session.save(tempStudent);
			session.getTransaction().commit();
			System.out.println("Done!!!");
		} finally {
			sessionFactory.close();
		}
	}

}
